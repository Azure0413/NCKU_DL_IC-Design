 This repo is about YOLOv2 accelerator implemented in vivado HLS 2018.2
 Following below, create HLS project using vivado tcl:
 1. open vivado tcl
 2. cd your_directory
 3. type vivado_hls –f script.tcl  
 
 PS:only cnn.cpp and cnn.h are source code, the others are parts of test bench.Two other files about weight and bias are available [YOLOv2 Weight & BIAS in BaiDu CloudDisk](https://pan.baidu.com/s/1v1U78fdYJ0p8XWmWXA3P0Q).
